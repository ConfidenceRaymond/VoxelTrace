# DRAFT SITE QUERIES (deterministic; not sent)

Generated from reason codes. Review and edit before any contact with a site.

## DRAFT SITE QUERY: SITE-A / DEMO-05-MISSING_DOSE / `ANONYMIZATION_LOSS`

- Scans: FOLLOWUP
- Fields: (see evidence)
- Evidence: RadionuclideTotalDose=ABSENT (UNKNOWN_OR_STRIPPED)

Quantitative attributes appear to have been removed during de-identification (see evidence). Please re-export with patient characteristics and timing retained.

## DRAFT SITE QUERY: SITE-A / DEMO-05-MISSING_DOSE / `MISSING_REQUIRED_TAG`

- Scans: eanm-fdg-2.0 BASELINE->FOLLOWUP, percist-1.0 BASELINE->FOLLOWUP, qiba-fdg-1.14 BASELINE->FOLLOWUP
- Fields: PERCIST-DOSE-DIFF: RadionuclideTotalDose, VT-SUV-BOTH: MISSING_RADIONUCLIDETOTALDOSE
- Evidence: FOLLOWUP: MISSING_RADIONUCLIDETOTALDOSE; injected activity unavailable

A required DICOM attribute is missing (see field). Please re-export with it populated or provide the value from the site record.

## DRAFT SITE QUERY: SITE-A / DEMO-05-MISSING_DOSE / `SUV_REFUSED`

- Scans: eanm-fdg-2.0 BASELINE->FOLLOWUP, percist-1.0 BASELINE->FOLLOWUP, qiba-fdg-1.14 BASELINE->FOLLOWUP
- Fields: EANM-UPTAKE-DIFF: FOLLOWUP.uptake, EANM-UPTAKE-WINDOW: FOLLOWUP.uptake, PERCIST-UPTAKE-DIFF: FOLLOWUP.uptake, PERCIST-UPTAKE-WINDOW: FOLLOWUP.uptake, QIBA-UPTAKE-DIFF: FOLLOWUP.uptake, QIBA-UPTAKE-WINDOW: FOLLOWUP.uptake
- Evidence: strict SUV/timing refused: MISSING_RADIONUCLIDETOTALDOSE

The quantitative metadata were refused by the strict SUV validator (see evidence). Please review the listed attributes with the site.

## DRAFT SITE QUERY: SITE-C / DEMO-09-REAL-PAIR / `ANONYMIZATION_LOSS`

- Scans: BASELINE
- Fields: (see evidence)
- Evidence: RadiopharmaceuticalStartDateTime=ABSENT (UNKNOWN_OR_STRIPPED)

Quantitative attributes appear to have been removed during de-identification (see evidence). Please re-export with patient characteristics and timing retained.

## DRAFT SITE QUERY: SITE-C / DEMO-09-REAL-PAIR / `MISSING_PATIENTSIZE`

- Scans: BASELINE
- Fields: PatientSize (0010,1020)
- Evidence: PatientSize absent or empty

Patient height is absent. Please provide height at the time of each scan (needed for lean-body-mass SUL); ensure de-identification retains patient characteristics (DICOM PS3.15 E.3.7).

## DRAFT SITE QUERY: SITE-D / DEMO-06-ANONYMIZATION_LOSS / `AMBIGUOUS_RECONSTRUCTION`

- Scans: eanm-fdg-2.0 BASELINE->FOLLOWUP, percist-1.0 BASELINE->FOLLOWUP, qiba-fdg-1.14 BASELINE->FOLLOWUP
- Fields: EANM-SAME-SYSTEM-SETTINGS: iterations, EANM-SAME-SYSTEM-SETTINGS: post_filter, EANM-SAME-SYSTEM-SETTINGS: psf_resolution_modelling, EANM-SAME-SYSTEM-SETTINGS: reconstruction_method, EANM-SAME-SYSTEM-SETTINGS: subsets, EANM-SAME-SYSTEM-SETTINGS: time_of_flight, VT-PROTOCOL-IDENTITY: iterations, VT-PROTOCOL-IDENTITY: post_filter, VT-PROTOCOL-IDENTITY: psf_resolution_modelling, VT-PROTOCOL-IDENTITY: reconstruction_method, VT-PROTOCOL-IDENTITY: subsets, VT-PROTOCOL-IDENTITY: time_of_flight
- Evidence: iterations unknown on at least one timepoint; post_filter unknown on at least one timepoint; psf_resolution_modelling unknown on at least one timepoint; reconstruction_method unknown on at least one timepoint; subsets unknown on at least one timepoint; time_of_flight unknown on at least one timepoint

Reconstruction identity between baseline and follow-up cannot be established from the images. Please provide the reconstruction protocol used at both timepoints (a scanner protocol export or a signed physicist record).

## DRAFT SITE QUERY: SITE-D / DEMO-06-ANONYMIZATION_LOSS / `RECONSTRUCTION_INCOMPLETE`

- Scans: FOLLOWUP
- Fields: ReconstructionMethod / iterations / subsets / kernel / TOF / PSF
- Evidence: missing: reconstruction_method, iterations, subsets, convolution_kernel, time_of_flight, psf_resolution_modelling

The PET series does not record the full reconstruction (method, iterations, subsets, post-filter, TOF, PSF). Please provide the scanner reconstruction protocol for this scan, or re-export with the standard reconstruction attributes populated.

