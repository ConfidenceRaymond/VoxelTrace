# Audit summary: VOXELTRACE-DEMONSTRATION-AUDIT

RESEARCH PROTOTYPE - NOT FOR CLINICAL DIAGNOSIS

| Subjects | Pairs | Real pairs | Scans | Pending reference reviews |
|---|---|---|---|---|
| 9 | 7 | 0 | 16 | 4 |

## Verdicts

| Rule set | ASSESSABLE | ASSESSABLE_WITH_WARNINGS | INSUFFICIENT_INFORMATION | NOT_ASSESSABLE |
|---|---|---|---|---|
| qiba-fdg-1.14 | 1 | 0 | 2 | 4 |
| eanm-fdg-2.0 | 1 | 0 | 2 | 4 |
| percist-1.0 | 1 | 0 | 2 | 4 |

## Top blocking reasons (pairs affected, any rule set)

| Reason | Pairs | Rule sets | Site can fix | Recommendation |
|---|---|---|---|---|
| EANM-SAME-SYSTEM-SETTINGS FAIL | 3 | eanm-fdg-2.0 | NO | criterion not met (identical acquisition/reconstruction/correction settings: manufacturer, scanner_model, image_units, decay_correction, correction_state, voxel_size, reconstruction_method, iterations, subsets, time_of_flight, psf_resolution_modelling, post_filter); a re-export cannot change measured values |
| VT-PROTOCOL-IDENTITY FAIL | 3 | eanm-fdg-2.0, percist-1.0, qiba-fdg-1.14 | NO | criterion not met (identical acquisition/reconstruction/correction settings: manufacturer, scanner_model, image_units, decay_correction, correction_state, voxel_size, reconstruction_method, iterations, subsets, time_of_flight, psf_resolution_modelling, post_filter); a re-export cannot change measured values |
| AMBIGUOUS_RECONSTRUCTION | 1 | eanm-fdg-2.0, percist-1.0, qiba-fdg-1.14 | YES | provide reconstruction protocol (algorithm, iterations, subsets, TOF, PSF, filter, voxel size) from the site imaging manual or structured attributes |
| EANM-UPTAKE-DIFF FAIL | 1 | eanm-fdg-2.0 | NO | criterion not met (|follow-up - baseline| <= 10.0 min); a re-export cannot change measured values |
| EANM-UPTAKE-WINDOW FAIL | 1 | eanm-fdg-2.0 | NO | criterion not met (55.0 <= uptake <= 75.0 min at every timepoint); a re-export cannot change measured values |

## Executive summary

VOXELTRACE-DEMONSTRATION-AUDIT: 7 baseline/follow-up pair(s) from 9 subject(s), 16 scan(s); 0 pair(s) are real data.
qiba-fdg-1.14: 1 ASSESSABLE, 2 INSUFFICIENT_INFORMATION, 4 NOT_ASSESSABLE.
eanm-fdg-2.0: 1 ASSESSABLE, 2 INSUFFICIENT_INFORMATION, 4 NOT_ASSESSABLE.
percist-1.0: 1 ASSESSABLE, 2 INSUFFICIENT_INFORMATION, 4 NOT_ASSESSABLE.
1 scan(s) cannot be quantified as exported (preflight DO_NOT_QUANTIFY).
4 reference-region proposal(s) await a human decision; until then the dependent rules stay UNKNOWN.
Recommended actions, most frequent blocking reason first:
1. EANM-SAME-SYSTEM-SETTINGS FAIL (3 pair(s); site can fix: NO): criterion not met (identical acquisition/reconstruction/correction settings: manufacturer, scanner_model, image_units, decay_correction, correction_state, voxel_size, reconstruction_method, iterations, subsets, time_of_flight, psf_resolution_modelling, post_filter); a re-export cannot change measured values.
2. VT-PROTOCOL-IDENTITY FAIL (3 pair(s); site can fix: NO): criterion not met (identical acquisition/reconstruction/correction settings: manufacturer, scanner_model, image_units, decay_correction, correction_state, voxel_size, reconstruction_method, iterations, subsets, time_of_flight, psf_resolution_modelling, post_filter); a re-export cannot change measured values.
3. AMBIGUOUS_RECONSTRUCTION (1 pair(s); site can fix: YES): provide reconstruction protocol (algorithm, iterations, subsets, TOF, PSF, filter, voxel size) from the site imaging manual or structured attributes.
4. EANM-UPTAKE-DIFF FAIL (1 pair(s); site can fix: NO): criterion not met (|follow-up - baseline| <= 10.0 min); a re-export cannot change measured values.
5. EANM-UPTAKE-WINDOW FAIL (1 pair(s); site can fix: NO): criterion not met (55.0 <= uptake <= 75.0 min at every timepoint); a re-export cannot change measured values.
These recommendations are the catalogued remediations of the observed reason codes. They do not change any verdict.

---

# VoxelTrace PET Comparability Audit: VOXELTRACE-DEMONSTRATION-AUDIT

RESEARCH PROTOTYPE - NOT FOR CLINICAL DIAGNOSIS Deterministic audit; no AI. Automated verdicts are never modified by review, attestation or adjudication records, which are reported separately.

## Preflight

```
{
  "scans": 16,
  "pet_series": 16,
  "scan_states": {
    "READY_WITH_WARNINGS": 15,
    "DO_NOT_QUANTIFY": 1
  },
  "series_states": {
    "READY_WITH_WARNINGS": 15,
    "DO_NOT_QUANTIFY": 1
  },
  "reason_codes": {
    "DERIVED_IMAGE": 16,
    "ANONYMIZATION_LOSS": 2,
    "MISSING_RADIONUCLIDETOTALDOSE": 1,
    "RECONSTRUCTION_INCOMPLETE": 1,
    "CORRECTIONS_NOT_DECLARED": 1,
    "INJECTION_DATE_FROM_SERIES": 1,
    "MISSING_PATIENTSIZE": 1
  }
}
```

## Scanners

- SIEMENS Biograph128_mCT sw=['VG60A']: 14 scan(s)
- SIEMENS Biograph128_mCT sw=['VG70A']: 1 scan(s)
- SIEMENS SOMATOM Definition AS_mCT sw=['syngo MI.PET/CT 2012A']: 1 scan(s)

## qiba-fdg-1.14

### REAL DATA verdicts

none

### SYNTHETIC TEST DATA verdicts

{'ASSESSABLE': 1, 'NOT_ASSESSABLE': 4, 'INSUFFICIENT_INFORMATION': 2}

### HUMAN-REVIEWED EVIDENCE

reference regions with a human decision: ['DEMO-01-IDENTITY/BASELINE', 'DEMO-02-RECON_BLUR/BASELINE', 'DEMO-03-RECON_METADATA/BASELINE', 'DEMO-04-UPTAKE_VIOLATION/BASELINE', 'DEMO-05-MISSING_DOSE/BASELINE', 'DEMO-06-ANONYMIZATION_LOSS/BASELINE', 'DEMO-07-CORRECTION_MISMATCH/BASELINE']

### EXTERNALLY ATTESTED EVIDENCE

pairs whose protocol identity rests on a LEVEL_C attestation: none

### IMAGE-DERIVED CORROBORATION

none (the audit never uses image-derived evidence for a rule)

### UNRESOLVED EVIDENCE

blocking UNKNOWN rules: {'VT-SUV-BOTH': 1, 'QIBA-UPTAKE-WINDOW': 1, 'QIBA-UPTAKE-DIFF': 1, 'VT-PROTOCOL-IDENTITY': 1}
II reason codes: {'MISSING_REQUIRED_TAG': 1, 'SUV_REFUSED': 1, 'AMBIGUOUS_RECONSTRUCTION': 1}

### Rule status

- VT-SUV-BOTH: {'PASS': 6, 'UNKNOWN': 1}
- VT-TRACER-SAME: {'PASS': 7}
- VT-PROTOCOL-IDENTITY: {'PASS': 3, 'FAIL': 3, 'UNKNOWN': 1}
- QIBA-UPTAKE-WINDOW: {'PASS': 5, 'FAIL': 1, 'UNKNOWN': 1}
- QIBA-UPTAKE-DIFF: {'PASS': 5, 'FAIL': 1, 'UNKNOWN': 1}
- QIBA-SAME-SYSTEM: {'PASS': 7}

## eanm-fdg-2.0

### REAL DATA verdicts

none

### SYNTHETIC TEST DATA verdicts

{'ASSESSABLE': 1, 'NOT_ASSESSABLE': 4, 'INSUFFICIENT_INFORMATION': 2}

### HUMAN-REVIEWED EVIDENCE

reference regions with a human decision: ['DEMO-01-IDENTITY/BASELINE', 'DEMO-02-RECON_BLUR/BASELINE', 'DEMO-03-RECON_METADATA/BASELINE', 'DEMO-04-UPTAKE_VIOLATION/BASELINE', 'DEMO-05-MISSING_DOSE/BASELINE', 'DEMO-06-ANONYMIZATION_LOSS/BASELINE', 'DEMO-07-CORRECTION_MISMATCH/BASELINE']

### EXTERNALLY ATTESTED EVIDENCE

pairs whose protocol identity rests on a LEVEL_C attestation: none

### IMAGE-DERIVED CORROBORATION

none (the audit never uses image-derived evidence for a rule)

### UNRESOLVED EVIDENCE

blocking UNKNOWN rules: {'VT-SUV-BOTH': 1, 'EANM-UPTAKE-WINDOW': 1, 'EANM-UPTAKE-DIFF': 1, 'VT-PROTOCOL-IDENTITY': 1, 'EANM-SAME-SYSTEM-SETTINGS': 1}
II reason codes: {'MISSING_REQUIRED_TAG': 1, 'SUV_REFUSED': 1, 'AMBIGUOUS_RECONSTRUCTION': 1, 'NEVER_ENCODED': 1}

### Rule status

- VT-SUV-BOTH: {'PASS': 6, 'UNKNOWN': 1}
- VT-TRACER-SAME: {'PASS': 7}
- VT-PROTOCOL-IDENTITY: {'PASS': 3, 'FAIL': 3, 'UNKNOWN': 1}
- EANM-UPTAKE-WINDOW: {'PASS': 5, 'FAIL': 1, 'UNKNOWN': 1}
- EANM-UPTAKE-DIFF: {'PASS': 5, 'FAIL': 1, 'UNKNOWN': 1}
- EANM-SAME-SYSTEM-SETTINGS: {'PASS': 3, 'FAIL': 3, 'UNKNOWN': 1}
- EANM-EARL-RECON: {'PASS': 4, 'UNKNOWN': 3}

## percist-1.0

### REAL DATA verdicts

none

### SYNTHETIC TEST DATA verdicts

{'ASSESSABLE': 1, 'NOT_ASSESSABLE': 4, 'INSUFFICIENT_INFORMATION': 2}

### HUMAN-REVIEWED EVIDENCE

reference regions with a human decision: ['DEMO-01-IDENTITY/BASELINE', 'DEMO-02-RECON_BLUR/BASELINE', 'DEMO-03-RECON_METADATA/BASELINE', 'DEMO-04-UPTAKE_VIOLATION/BASELINE', 'DEMO-05-MISSING_DOSE/BASELINE', 'DEMO-06-ANONYMIZATION_LOSS/BASELINE', 'DEMO-07-CORRECTION_MISMATCH/BASELINE']

### EXTERNALLY ATTESTED EVIDENCE

pairs whose protocol identity rests on a LEVEL_C attestation: none

### IMAGE-DERIVED CORROBORATION

none (the audit never uses image-derived evidence for a rule)

### UNRESOLVED EVIDENCE

blocking UNKNOWN rules: {'VT-SUV-BOTH': 1, 'PERCIST-UPTAKE-DIFF': 1, 'PERCIST-LIVER-SUL-STABILITY': 1, 'VT-PROTOCOL-IDENTITY': 1}
II reason codes: {'MANUAL_OR_REFERENCE_MASK_REQUIRED': 1, 'MISSING_REQUIRED_TAG': 1, 'SUV_REFUSED': 1, 'AMBIGUOUS_RECONSTRUCTION': 1}

### Rule status

- VT-SUV-BOTH: {'PASS': 6, 'UNKNOWN': 1}
- VT-TRACER-SAME: {'PASS': 7}
- VT-PROTOCOL-IDENTITY: {'PASS': 3, 'FAIL': 3, 'UNKNOWN': 1}
- PERCIST-UPTAKE-WINDOW: {'PASS': 5, 'FAIL': 1, 'UNKNOWN': 1}
- PERCIST-UPTAKE-DIFF: {'PASS': 5, 'FAIL': 1, 'UNKNOWN': 1}
- PERCIST-LIVER-SUL-STABILITY: {'PASS': 5, 'FAIL': 1, 'UNKNOWN': 1}
- PERCIST-DOSE-DIFF: {'PASS': 6, 'UNKNOWN': 1}
- PERCIST-SAME-SCANNER-SOFTWARE: {'PASS': 7}
- PERCIST-BASELINE-MEASURABLE: {'PASS': 7}

## Protocol drift

events: {'RECONSTRUCTION_CHANGE': 4, 'CORRECTION_CHANGE': 1, 'FILTER_CHANGE': 2, 'UNKNOWN_PROTOCOL_DRIFT': 6, 'UPTAKE_OUTLIER': 1}
- SITE-A: 8 scans, 3 distinct protocols, events {'RECONSTRUCTION_CHANGE': 4, 'CORRECTION_CHANGE': 1}
- SITE-B: 1 scans, 1 distinct protocols, events none
- SITE-C: 1 scans, 1 distinct protocols, events none
- SITE-D: 6 scans, 3 distinct protocols, events {'FILTER_CHANGE': 2, 'UNKNOWN_PROTOCOL_DRIFT': 6, 'UPTAKE_OUTLIER': 1}

## Review tasks

pending human reference-region reviews: 4

## Attestations / adjudications

attestations supplied: 0
adjudication status: {'NOT_ADJUDICATED': 21}

## DRAFT site queries (7)

See reports/site_queries.md (not sent).
